module app.demo {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens app.greenhouse to javafx.fxml;
    exports app.greenhouse;
}