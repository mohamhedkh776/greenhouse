package app.greenhouse;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.DatePicker;
import java.time.LocalDate;

import java.sql.Connection;

import static app.greenhouse.app.con;

public class MethodSelectionUI {

    public static void showMethodSelection(Connection con) {
        Stage methodStage = new Stage();

        VBox methodSelectionVBox = new VBox(10);
        methodSelectionVBox.setAlignment(Pos.CENTER);

        Label titleLabel = new Label("Select Method:");

        Button loggedValueMaxButton = new Button("Logged Value Max");
        loggedValueMaxButton.setOnAction(e -> {
            Thread thread2 = new Thread(() -> {
                // Use Platform.runLater to ensure that UI updates are performed
                // on the JavaFX Application Thread.
                Platform.runLater(() -> Methods.LoggedValueMax(con, createResultLabel(methodStage)));
            });
            thread2.start();
            System.out.println(thread2.getState());
        });




        Button totalLoggedValueButton = new Button("Total Logged Value");

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> methodStage.close());
        totalLoggedValueButton.setOnAction( e-> {
            Platform.runLater(() -> showTotalLoggedValue(con, methodStage, backButton));
        });

        Button lineIDWLoggedValueMinButton = new Button("LineID with Minimum Logged Value");
        lineIDWLoggedValueMinButton.setOnAction(e -> Methods.LineIDWLoggedValueMin(con, createResultLabel(methodStage)));

        Button maxProductionDateRangeButton = new Button("Max Production Date Range Query");
        maxProductionDateRangeButton.setOnAction(e -> showMaxProductionDateRange(con, methodStage, backButton));

        Button zeroLoggedValueButton = new Button("Zero Logged Value");
        zeroLoggedValueButton.setOnAction(e -> Methods.ZeroLoggedValue(methodStage, con, createResultLabel(methodStage)));

        methodSelectionVBox.getChildren().addAll(
                titleLabel, loggedValueMaxButton, totalLoggedValueButton,
                lineIDWLoggedValueMinButton, maxProductionDateRangeButton, zeroLoggedValueButton
        );

        Scene methodSelectionScene = new Scene(methodSelectionVBox, 400, 300);
        methodStage.setScene(methodSelectionScene);
        methodStage.setTitle("Method Selection");
        methodStage.show();
    }

    private static void showTotalLoggedValue(Connection con, Stage methodStage, Button backButton) {
        VBox options = new VBox(10);
        Label startLabel = new Label("Start LogID");
        Label endLabel = new Label("End LogID");
        TextField startTextField = new TextField();
        TextField endTextField = new TextField();
        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            Thread thread = new Thread(() -> {
                try {
                    int startLogID = Integer.parseInt(startTextField.getText());
                    int endLogID = Integer.parseInt(endTextField.getText());
                    // Moved createLineChartPage call inside Platform.runLater to ensure UI updates are done on the JavaFX Application Thread
                    Platform.runLater(() -> Methods.createLineChartPage(methodStage, con, startLogID, endLogID, createResultLabel(methodStage)));
                } catch (NumberFormatException exception) {
                    // Consider updating this to alert the user via the UI rather than just printing a stack trace.
                    Platform.runLater(() -> exception.printStackTrace());
                }
            });
            thread.start();
            System.out.println(thread.getState());
        });


        HBox HBoxOptions = new HBox(10);
        HBoxOptions.getChildren().addAll(submitButton, backButton);
        HBoxOptions.setAlignment(Pos.CENTER);
        options.setAlignment(Pos.CENTER);
        options.getChildren().addAll(startLabel, startTextField, endLabel, endTextField, HBoxOptions);

        Scene submitValues = new Scene(options, 500, 500);
        methodStage.setScene(submitValues);
        methodStage.show();
    }

    private static void showMaxProductionDateRange(Connection con, Stage methodStage, Button backButton) {
        VBox options = new VBox(10);
        Label startLabel = new Label("Start Date");
        Label endLabel = new Label("End Date");
        DatePicker startDatePicker = new DatePicker();
        DatePicker endDatePicker = new DatePicker();

        startDatePicker.setValue(LocalDate.now());
        endDatePicker.setValue(LocalDate.now());

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            LocalDate startDate = startDatePicker.getValue();
            LocalDate endDate = endDatePicker.getValue();
            String startLogID = startDate.toString();
            String endLogID = endDate.toString();
            Methods.MaxProductionDateRangeQuery(con, startLogID, endLogID, createResultLabel(methodStage));
        });

        HBox horBox = new HBox(10);
        horBox.setAlignment(Pos.CENTER);
        options.setAlignment(Pos.CENTER);
        horBox.getChildren().addAll(submitButton, backButton);
        options.getChildren().addAll(startLabel, startDatePicker, endLabel, endDatePicker, horBox);

        Scene maxProductionScene = new Scene(options, 500, 500);
        methodStage.setScene(maxProductionScene);
        methodStage.show();
    }

    private static Label createResultLabel(Stage stage) {
        Label resultLabel = new Label();
        VBox resultVBox = new VBox(10);
        resultVBox.setAlignment(Pos.CENTER);

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> {
            stage.close();
            showMethodSelection(con);
        });

        resultVBox.getChildren().addAll(resultLabel, backButton);
        ScrollPane scrollPane = new ScrollPane(resultVBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);

        Scene resultScene = new Scene(scrollPane, 600, 400);
        stage.setScene(resultScene);
        stage.setTitle("Method Result");
        stage.show();

        return resultLabel;
    }
}
