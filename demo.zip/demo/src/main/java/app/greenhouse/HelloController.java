//מוחמד חליל 212134274
//מוחמד דרוויש 319043402
package app.greenhouse;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class HelloController {
    @FXML
    private Label welcomeText;

    public HelloController(Stage primaryStage) {
    }

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to Green House Database!");
    }

    public Scene getScene() {
        // Assuming the FXML file is loaded externally and the root node is set to the scene
        return welcomeText.getScene();
    }
}
