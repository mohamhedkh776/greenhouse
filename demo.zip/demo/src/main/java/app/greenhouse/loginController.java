package app.greenhouse;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class loginController {

    @FXML
    private Button loginButton;

    @FXML
    private TextField loginTxtField;

    @FXML
    private PasswordField passwordTxtField;

    @FXML
    private AnchorPane mainAnchor;

    @FXML
    void handleEveryAction(ActionEvent event) {

        if (event.getSource().equals(loginButton)){
                String user = loginTxtField.getText();
                String password = passwordTxtField.getText();

                if (!user.isEmpty()) {
                    app.con = SQLConnection.connectoToDatabase(SQLConnection.url, user, password);
                    SQLConnection.useDatabase(app.con);
                    MethodSelectionUI.showMethodSelection(app.con); // Call the new method here
                }
        }
    }

}
