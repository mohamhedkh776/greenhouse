package app.greenhouse;
import java.sql.*;

public class SQLConnection{
    public static final String url = "jdbc:mysql://localhost:3306/sys_config";
    static final String username = "root";
    static final String password = "Kh@212134274";
    public static Connection connectoToDatabase(String url, String username, String password) {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, username, password);

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return con;

    }
    public static void useDatabase(Connection con){
        try{
            String query = "use sys_config";
            Statement use = con.createStatement();
            use.execute(query);

        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public static void closeConnection(Connection con){
        try{
            if (con != null && !con.isClosed()) {
                con.close();
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }



}