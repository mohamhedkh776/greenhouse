//מוחמד חליל 212134274
//מוחמד דרוויש 319043402
package app.greenhouse;
import javafx.geometry.Pos;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;


public abstract class Methods {


    public static void LoggedValueMax(Connection con, Label outputLabel) {
        Runnable task = () -> {
            try {
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT LogID, LineID, LogTime, LoggedValue FROM linesproductivity_updated WHERE LoggedValue = (SELECT MAX(LoggedValue) FROM linesproductivity_updated)");
                if (rs.next()) {
                    int logID = rs.getInt("LogID");
                    String lineID = rs.getString("LineID");
                    String logTime = rs.getString("LogTime");
                    float maxLoggedValue = rs.getFloat("LoggedValue");
                    // Update UI on the JavaFX Application Thread
                    javafx.application.Platform.runLater(() -> {
                        outputLabel.setText("LogID: " + logID + "\t" + "LineID: " + lineID + "\t" + "LogTime: " + logTime + "\t" + " Maximum LoggedValue: " + maxLoggedValue);
                    });
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        };
        Thread thread = new Thread(task);
        thread.start();

    }


    public static ObservableList<LineProductivity> totalLoggedValue(Connection con, int startLogID, int endLogID) {
        ObservableList<LineProductivity> products = FXCollections.observableArrayList();

        try {
            String totalLoggedValueQuery = "SELECT LogID, SUM(LoggedValue) AS TotalLoggedValue FROM linesproductivity_updated WHERE LogID BETWEEN ? AND ? GROUP BY LogID";

            PreparedStatement totalLoggedValueStmt = con.prepareStatement(totalLoggedValueQuery);

            totalLoggedValueStmt.setInt(1, startLogID);
            totalLoggedValueStmt.setInt(2, endLogID);
            ResultSet totalLoggedValueRs = totalLoggedValueStmt.executeQuery();
            System.out.println("\nTotal LoggedValue for LogID in the range 1-6:");
            StringBuilder result = new StringBuilder("\nTotal LoggedValue for LogID in the range " + startLogID + "-" + endLogID + ":\n");
            while (totalLoggedValueRs.next()) {
                int logId = totalLoggedValueRs.getInt("LogID");
                float loggedValue = totalLoggedValueRs.getFloat("TotalLoggedValue");
                System.out.println(totalLoggedValueRs.getInt("LogID") + "\t" + totalLoggedValueRs.getFloat("TotalLoggedValue"));
                LineProductivity product = new LineProductivity(logId, loggedValue);
                products.add(product);
            }
//            outputLabel.setText(result.toString());

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }
    public static void createLineChartPage(Stage primaryStage,  Connection con, int startLogId, int endLogId, Label outputLabel) {
//        Stage primaryStage = new Stage();
        Button backButton = new Button("Back");
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        LineChart<String, Number> lineChart = new LineChart<>(xAxis, yAxis);

        ObservableList<LineProductivity> productList = totalLoggedValue(con, startLogId, endLogId);

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        for (LineProductivity product : productList) {
            series.getData().add(new XYChart.Data<>(String.valueOf(product.getLogID()), product.getLoggedValue()));
        }

        lineChart.getData().add(series);

        VBox vbox = new VBox(lineChart, backButton);
        vbox.setAlignment(Pos.CENTER);
        Scene scene = new Scene(vbox, 600, 500);
        backButton.setOnAction(e -> {
            primaryStage.close();
            MethodSelectionUI.showMethodSelection(con);
        });

        primaryStage.setTitle("Total loggedValue LineChart based on LineID");
        primaryStage.setScene(scene);

        primaryStage.show();
    }


    public static void LineIDWLoggedValueMin(Connection con, Label outputLabel) {
        try {
            //String LineIDWLoggedValueMin = "SELECT LineID, MIN(LoggedValue) AS MinLoggedValue FROM linesproductivity_updated GROUP BY LineID";
            String LineIDWLoggedValueMin = "SELECT LineId, LoggedValue FROM linesproductivity_updated WHERE LoggedValue = (SELECT MIN(NULLIF(LoggedValue,0)) FROM linesproductivity_updated)";
            try(PreparedStatement stmt = con.prepareStatement(LineIDWLoggedValueMin)) {
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    String lineID = rs.getString("LineID");
                    double minLoggedValue = rs.getDouble("LoggedValue");
                    System.out.println("\nLineID: " + lineID + "\t Minimum LoggedValue: " + minLoggedValue);
                    outputLabel.setText("\nLineID: " + lineID + "\t Minimum LoggedValue: " + minLoggedValue);
                }
                rs.close();
            }} catch (SQLException e) {
            e.printStackTrace();
        }

    }
    public static String MaxProductionDateRangeQuery(Connection con, String StartDate, String EndDate, Label outputLabel) {
        try {
            String MaxProductionDateRangeQuery = "SELECT LineID FROM linesproductivity_updated WHERE LogTime BETWEEN ? AND ? GROUP BY LineID ORDER BY SUM(LoggedValue) DESC LIMIT 1";

            PreparedStatement maxProductionDateRangeStmt = con.prepareStatement(MaxProductionDateRangeQuery);
            maxProductionDateRangeStmt.setString(1, StartDate);
            maxProductionDateRangeStmt.setString(2, EndDate);

            ResultSet maxProductionDateRangeRs = maxProductionDateRangeStmt.executeQuery();
            System.out.printf("\nLineID where production was maximal within the specified date range:%s to %s \n", StartDate, EndDate);
            StringBuilder result = new StringBuilder("\nLineID where production was maximal within the specified date range:" + StartDate + " to " + EndDate + "\n");

            if (maxProductionDateRangeRs.next()) {
                String MaxProduction = maxProductionDateRangeRs.getString("LineID");
                System.out.println(MaxProduction);
                result.append(MaxProduction);
            } else{
                System.out.println("No data in this range has been found!");
            result.append("No data in this range has been found!");
        }


        outputLabel.setText(result.toString());
    }catch(Exception e){
            System.out.println(e);
            outputLabel.setText(e.toString());

        }
        return StartDate;
    }

    public static void ZeroLoggedValue(Stage primaryStage,Connection con, Label outputLabel){

        TableView<LineProductivity> tableView = new TableView<>();

        TableColumn<LineProductivity, Integer> logIdColumn = new TableColumn<>("logID");
        logIdColumn.setMinWidth(50);
        logIdColumn.setCellValueFactory(new PropertyValueFactory<>("logID"));


        TableColumn<LineProductivity, String> lineIdColumn = new TableColumn<>("lineID");
        lineIdColumn.setMinWidth(70);
        lineIdColumn.setCellValueFactory(new PropertyValueFactory<>("lineID"));

        TableColumn<LineProductivity, String> logTimeColumn = new TableColumn<>("LogTime");
        logTimeColumn.setMinWidth(170);
        logTimeColumn.setCellValueFactory(new PropertyValueFactory<>("logTime"));

        TableColumn<LineProductivity, Double> loggedValueColumn = new TableColumn<>("Logged Value");
        loggedValueColumn.setMinWidth(50);
        loggedValueColumn.setCellValueFactory(new PropertyValueFactory<>("loggedValue"));

        TableColumn<LineProductivity, Integer> cmdTypeColumn = new TableColumn<>("CmdType");
        cmdTypeColumn.setMinWidth(50);
        cmdTypeColumn.setCellValueFactory(new PropertyValueFactory<>("cmdType"));

        TableColumn<LineProductivity, String> descriptionColumn = new TableColumn<>("Description");
        descriptionColumn.setMinWidth(70);
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));

        TableColumn<LineProductivity, String> unitTypeColumn = new TableColumn<>("Unit Type");
        unitTypeColumn.setMinWidth(50);
        unitTypeColumn.setCellValueFactory(new PropertyValueFactory<>("unitType"));

        tableView.setItems(TotalLoggedValueZero(con));
        tableView.getColumns().addAll(logIdColumn, lineIdColumn, logTimeColumn, loggedValueColumn, cmdTypeColumn, descriptionColumn, unitTypeColumn);
        Button backButton = new Button("Back");
        VBox root = new VBox(outputLabel, tableView, backButton);
        root.setAlignment(Pos.CENTER);
        backButton.setOnAction(e -> {
            primaryStage.close();
            MethodSelectionUI.showMethodSelection(con);
        });


        Scene scene = new Scene(root, 600, 420);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Zero Logged Value");
        primaryStage.show();
    }

    public static ObservableList<LineProductivity> TotalLoggedValueZero(Connection con){
        ObservableList<LineProductivity> products = FXCollections.observableArrayList();

        try {
            String zeroLoggedValueQuery = "SELECT * FROM linesproductivity_updated WHERE LoggedValue = 0";
            PreparedStatement stmt = con.prepareStatement(zeroLoggedValueQuery);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int logID = rs.getInt("LogID");
                String lineID = rs.getString("LineID");
                String logTime = rs.getString("LogTime");
                float loggedValue = rs.getFloat("LoggedValue");
                int cmdType = rs.getInt("CmdType");
                String description = rs.getString("Description");
                String unitType = rs.getString("UnitType");

                products.add(new LineProductivity(logID, lineID, logTime, loggedValue, cmdType, description, unitType));
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return products;
    }


    public abstract void start(Stage primaryStage) throws IOException;
}
