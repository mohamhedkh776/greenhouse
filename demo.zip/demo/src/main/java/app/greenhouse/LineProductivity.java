package app.greenhouse;

public class LineProductivity {
    private Integer logID = 0;
    private String lineID = "";
    private String logTime = "";
    private float loggedValue = 0.0F;
    private Integer cmdType = 0;
    private String description= "";
    private String unitType = "";

    public LineProductivity(Integer logID, String lineID, String logTime, float loggedValue, Integer cmdType, String description, String unitType) {
        this.logID = logID;
        this.lineID = lineID;
        this.logTime = logTime;
        this.loggedValue = loggedValue;
        this.cmdType = cmdType;
        this.description = description;
        this.unitType = unitType;
    }

    public LineProductivity(Integer logID, float loggedValue){
        this.logID = logID;
        this.loggedValue = loggedValue;
    }

    public Integer getLogID() {
        return logID;
    }

    public String getLineID() {
        return lineID;
    }

    public String getLogTime() {
        return logTime;
    }

    public Float getLoggedValue() {
        return loggedValue;
    }

    public Integer getCmdType() {
        return cmdType;
    }

    public String getDescription() {
        return description;
    }

    public String getUnitType() {
        return unitType;
    }
}