package app.greenhouse;

import app.greenhouse.LineProductivity;
import app.greenhouse.Methods;
import app.greenhouse.SQLConnection;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.concurrent.atomic.AtomicInteger;

import javafx.util.Duration;



public class APPlication extends Application {

    private final TableView<LineProductivity> tableView = new TableView<>();
    private final Button executeButton = new Button("Execute Selected Queries");
    private final ComboBox<String> comboBox1 = new ComboBox<>();
    private final ComboBox<String> comboBox2 = new ComboBox<>();
    private final Label statusLabel = new Label("Select two queries to execute");
    private final ProgressBar progressBar = new ProgressBar(0);
    private final Label progressStatusLabel = new Label("Pending");
    private final AtomicInteger queryCompletionCount = new AtomicInteger(0);

    @Override
    public void start(Stage primaryStage) {
        comboBox1.getItems().addAll( "TotalLoggedValueForLogID", "lineIdWhereLoggedValueMin", "LoggedValueEqualsZero");
        comboBox2.getItems().addAll( "TotalLoggedValueForLogID", "lineIdWhereLoggedValueMin", "LoggedValueEqualsZero");

        setupTableView();

        executeButton.setOnAction(e -> {
            executeSelectedQueries();
            progressBar.setProgress(0);
            queryCompletionCount.set(0);
            progressStatusLabel.setText("Running...");
        });

        VBox root = new VBox(10, statusLabel, comboBox1, comboBox2, executeButton, progressBar, progressStatusLabel, tableView);
        Scene scene = new Scene(root, 800, 600);

        primaryStage.setTitle("Multi-Threaded Query Executor with Progress");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void executeSelectedQueries() {
        // This is a simplification. Actual connection handling should be more robust.
        String url = "jdbc:mysql://localhost:3306/sys_config"; // Update with your actual database connection details
        String user = "root";
        String password = "Kh@212134274";

        try {
            Connection connection = DriverManager.getConnection(url, user, password);
            
            // Run each selected query in its own thread
            new Thread(() -> runQuery(comboBox1.getValue(), connection)).start();
            new Thread(() -> runQuery(comboBox2.getValue(), connection)).start();
        } catch (Exception e) {
            Platform.runLater(() -> statusLabel.setText("Failed to connect to database."));
            e.printStackTrace();
        }
    }
    // Setup tableView and executeSelectedQueries methods remain the same

    private void runQuery(String queryName, Connection connection) {
        ObservableList<LineProductivity> result = switch (queryName) {
            case "TotalLoggedValueForLogID" -> Methods.totalLoggedValue(connection,1,6);
            case "LoggedValueEqualsZero" -> Methods.TotalLoggedValueZero(connection);
            default -> null;
        };
    
        if (result != null) {
            // Use an intermediate list to gradually add items to the TableView
            ObservableList<LineProductivity> intermediateList = FXCollections.observableArrayList();
            tableView.setItems(intermediateList);
    
            Timeline timeline = new Timeline();
            final int[] count = {0};
            int totalItems = result.size(); // Total items to add for calculating progress percentage
            for (LineProductivity product : result) {
                timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(0.001), e -> {
                    intermediateList.add(product);
                    // Update progress bar and label with each item added
                    double progress = (count[0] + 1) / (double) totalItems;
                    progressBar.setProgress(progress);
                    progressStatusLabel.setText(String.format("Running... %.0f%%", progress * 100));
                }));
                count[0]++;
            }
    
            timeline.setOnFinished(e -> {
                // Update status to complete when all items are added
                progressStatusLabel.setText(String.format("Complete. 100%%"));
            });
    
            timeline.play();
        } else {
            Platform.runLater(() -> progressStatusLabel.setText("Failed to execute query"));
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
    private void setupTableView() {
        // Assuming the Product class has the appropriate properties
        // Adjust column setup based on the actual Product class structure
        TableColumn<LineProductivity, Integer> logIdColumn = new TableColumn<>("logID");
        logIdColumn.setMinWidth(50);
        logIdColumn.setCellValueFactory(new PropertyValueFactory<>("logID"));
        

        TableColumn<LineProductivity, String> lineIdColumn = new TableColumn<>("lineID");
        lineIdColumn.setMinWidth(70);
        lineIdColumn.setCellValueFactory(new PropertyValueFactory<>("lineID"));

        TableColumn<LineProductivity, String> logTimeColumn = new TableColumn<>("LogTime");
        logTimeColumn.setMinWidth(170);
        logTimeColumn.setCellValueFactory(new PropertyValueFactory<>("logTime"));

        TableColumn<LineProductivity, Double> loggedValueColumn = new TableColumn<>("Logged Value");
        loggedValueColumn.setMinWidth(50);
        loggedValueColumn.setCellValueFactory(new PropertyValueFactory<>("loggedValue"));
        
        TableColumn<LineProductivity, Integer> cmdTypeColumn = new TableColumn<>("CmdType");
        cmdTypeColumn.setMinWidth(50);
        cmdTypeColumn.setCellValueFactory(new PropertyValueFactory<>("cmdType"));

        TableColumn<LineProductivity, String> descriptionColumn = new TableColumn<>("Description");
        descriptionColumn.setMinWidth(70);
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));

        TableColumn<LineProductivity, String> unitTypeColumn = new TableColumn<>("Unit Type");
        unitTypeColumn.setMinWidth(50);
        unitTypeColumn.setCellValueFactory(new PropertyValueFactory<>("unitType"));
        // Define cell value factories for each column based on Product properties
        tableView.getColumns().addAll(logIdColumn, lineIdColumn, logTimeColumn, loggedValueColumn, cmdTypeColumn, descriptionColumn, unitTypeColumn); // Add all necessary columns
    }
}
