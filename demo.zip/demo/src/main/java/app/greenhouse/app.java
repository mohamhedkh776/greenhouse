
package app.greenhouse;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;
import java.sql.Connection;

public class app extends Application {

    public static Connection con;

    @Override
    public void start(Stage primaryStage) throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/app/greenhouse/login.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        primaryStage.initStyle(StageStyle.DECORATED);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private VBox createLoginVBox(Stage primaryStage) {
        VBox loginVBox = new VBox(10);
        loginVBox.setAlignment(Pos.CENTER);

        Label titleLabel = new Label("Enter Database Connection Details");
        Label userLabel = new Label("Username:");
        Label passwordLabel = new Label("Password:");

        TextField userTextField = new TextField();
        PasswordField passwordField = new PasswordField();
        userTextField.setPrefHeight(2);
        userTextField.setPrefWidth(1);

        Button loginButton = new Button("Login");
        loginButton.setOnAction(e -> {
            String user = userTextField.getText();
            String password = passwordField.getText();

            if (!user.isEmpty()) {
                con = SQLConnection.connectoToDatabase(SQLConnection.url, user, password);
                SQLConnection.useDatabase(con);
                MethodSelectionUI.showMethodSelection(con); // Call the new method here
            }
        });

        loginVBox.getChildren().addAll(
                titleLabel, userLabel, userTextField,
                passwordLabel, passwordField, loginButton
        );

        return loginVBox;
    }

    public static void main(String[] args)  {

        launch(args);

    }
}
